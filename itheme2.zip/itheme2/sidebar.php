<?php if(!post_password_required()):?>
    <?php themify_sidebar_before(); //hook ?>
<div id="sidebar" itemscope="itemscope" itemtype="https://schema.org/WPSidebar">
	<?php themify_sidebar_start(); //hook ?>

            <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('sidebar-main') ); ?>

	<?php themify_sidebar_end(); //hook ?>
</div>
<!--/sidebar -->
    <?php themify_sidebar_after(); //hook ?>
<?php endif;?>
